package DrawingTool;

import java.awt.Point;

public class Window extends RectangularObject {

	public Window(Point position, int width, int height) {
		super(position, width, height);
	}

	@Override
	public void draw() {
		super.draw();
	}
}
