package DrawingTool;

import java.awt.Point;

public class PilotDoor extends RectangularObject {

	public PilotDoor(Point position, int width, int height) {
		super(position, width, height);
	}

	public void draw() {
		super.draw();
	}

}
